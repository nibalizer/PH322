l=0;
m=2;
while m<=n
   l=l+1;
   m=2*m;
end

