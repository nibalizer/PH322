x = -10:0.1:10;
plot (x, sin (x))

pause()
