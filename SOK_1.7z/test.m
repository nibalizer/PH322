dt = .01
T(1)= 0
t= 10

N=t/dt+1
for k=[2:N]
    fprintf('%f\n',k)
end

