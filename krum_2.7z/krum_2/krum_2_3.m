%Spencer Krum
%PH 322 problem form slyablus

fprintf('%s', 'Not really sure how to do this one, turning it in undone hoping Ill get time to do it and figure it out') 
